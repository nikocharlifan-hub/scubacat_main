import cv2
import mediapipe as mp
import math

# MediaPipe configuration for hand detection
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    max_num_hands=2,
    min_detection_confidence=0.8,  # Minimum confidence for detection
    min_tracking_confidence=0.8    # Minimum confidence for tracking
)
mp_draw = mp.solutions.drawing_utils

# Video path and camera capture
video_path = 'cat.mp4'
cap_cat = None
cap = cv2.VideoCapture(0)  # Open webcam
video_on = False

# Check if two points are close in hand space
def is_point_close(p1, p2, threshold=0.1):
    distance = math.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)
    return distance < threshold

# Check if the hand is in a closed fist position
def is_real_closed_fist(lm):
    fingertips = [8, 12, 16, 20]  
    palm_base = lm[0]  # Wrist
    closed = [is_point_close(lm[p], palm_base, 0.25) for p in fingertips]
    return all(closed)

# Check if the palm is open
def is_real_open_palm(lm):
    fingertip_bases = [(8, 6), (12, 10), (16, 14), (20, 18)]  # Fingertips and finger bases
    return all([lm[p].y < lm[b].y for p, b in fingertip_bases])

# Main loop for detection and video control
while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)  # Mirror effect
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(frame_rgb)  # Process image with MediaPipe

    fist_detected = False
    palm_detected = False

    if result.multi_hand_landmarks:
        for hand_landmarks in result.multi_hand_landmarks:
            mp_draw.draw_landmarks(
                frame,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS
            )  # Draw landmarks

            lm = hand_landmarks.landmark

            # Check for closed fist and open palm gestures
            if is_real_closed_fist(lm):
                fist_detected = True
            elif is_real_open_palm(lm):
                palm_detected = True

    # Video control: start on fist detection and stop on palm detection
    if fist_detected and not video_on:
        cap_cat = cv2.VideoCapture(video_path)  # Open video

        if cap_cat.isOpened():
            video_on = True
            print("Real fist detected! Cat ON.")

    elif palm_detected and video_on:
        video_on = False  # Stop video

        if cap_cat:
            cap_cat.release()

        cv2.destroyWindow("Scubacat")
        print("Palm detected: Cat OFF.")

    # Display video if enabled
    if video_on and cap_cat is not None:
        ret_v, frame_cat = cap_cat.read()

        if not ret_v:
            cap_cat.set(cv2.CAP_PROP_POS_FRAMES, 0)  # Restart video
            ret_v, frame_cat = cap_cat.read()

        if ret_v:
            frame_cat = cv2.resize(frame_cat, (400, 400))  # Resize video
            cv2.imshow("Scubacat", frame_cat)  # Show video

    cv2.imshow("Main Camera", frame)  # Show live camera feed

    # Exit loop when 'Esc' is pressed
    if cv2.waitKey(1) & 0xFF == 27:
        break

# Release resources
cap.release()

if cap_cat:
    cap_cat.release()

cv2.destroyAllWindows()